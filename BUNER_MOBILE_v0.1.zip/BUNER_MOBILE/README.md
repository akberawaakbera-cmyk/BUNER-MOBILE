# BUNER MOBILE — Web Prototype 0.1

A mobile-first 3D battle-royale-style prototype using HTML, CSS, JavaScript, and Three.js.

## Files
- `index.html` — lobby and game UI
- `style.css` — responsive mobile UI
- `game.js` — Three.js scene, character, terrain, houses, trees, and controls
- `assets/` — reserved for original models, textures, and sound files

## Run on iPhone
Because the game uses JavaScript modules and loads Three.js from a CDN, host it as a website rather than opening `index.html` in the Files app.

1. Create a new GitHub repository named `BUNER-MOBILE`.
2. Upload `index.html`, `style.css`, `game.js`, and the `assets` folder.
3. Open repository Settings → Pages.
4. Set deployment to `Deploy from a branch`, choose `main` and `/ (root)`, then save.
5. Open the GitHub Pages URL in Safari after deployment finishes.

Internet is required for Three.js and the fonts.

## Controls
- Mobile: use the left joystick to move; drag on the right side to rotate the camera; use JUMP and FIRE.
- Keyboard: WASD / arrow keys to move, Shift to run, Space to jump.
- START enters the training environment; EXIT returns to the lobby.

## Current limitations
This is an early playable foundation, not a complete online game. It uses simple procedural placeholder geometry. It does not yet have real weapon damage, enemy AI, login backend, matchmaking, anti-cheat, or multiplayer servers. Future builds can add original character models, improved interiors, weapon pickups, animation, and online systems.
